import sys
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import validate_p00

class TestP00Structure(unittest.TestCase):
    def test_registry_integrity(self):
        result=validate_p00.validate()
        self.assertEqual(result['requirements'],40)
        self.assertEqual(result['decisions'],31)
        self.assertEqual(result['nfr'],16)
    def test_flags_all_disabled(self):
        import json
        cfg=json.loads((ROOT/'config/features.example.json').read_text(encoding='utf-8'))
        self.assertFalse(any(cfg['features'].values()))
    def test_no_fake_approval(self):
        gates=validate_p00.read_csv('gates.csv')
        self.assertTrue(all(x['status'] in {'NOT_APPROVED','NOT_STARTED'} for x in gates))

if __name__=='__main__': unittest.main()
