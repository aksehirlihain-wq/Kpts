import unittest,sys,json,csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from audit_source_integrity import audit
from generate_p00_preview import generate
class CanonicalRegression(unittest.TestCase):
  def test_source_byte_identity(self):
    errors,a,b=audit();self.assertEqual(errors,[]);self.assertEqual((a,b),(56,49))
  def test_preview_matches_canonical(self):
    actual=json.loads((ROOT.parent/'src/data/p00-canonical.json').read_text(encoding='utf8'))
    self.assertEqual(actual,generate())
    self.assertEqual(actual['invariants'][0]['title'],'Fiziksel ve mali otorite ayrılığı')
    self.assertEqual(actual['invariants'][-1]['title'],'Test ve kanıt doğruluğu')
    self.assertEqual(actual['gates'][1]['phases'],'P01–P04')
    self.assertEqual(actual['gates'][9]['phases'],'P32–P33')
    self.assertEqual(actual['requirements'][0]['title'],'Kapsam/Yönetişim')
    self.assertEqual(actual['decisions'][1]['subject'],'e-Fatura/e-Arşiv belge türü ve düzenleme zamanı')
  def test_safety_and_pending(self):
    d=generate()
    self.assertTrue(all(v is False for v in d['features'].values()))
    self.assertTrue(all(x['status']=='OPEN' for x in d['blockers']))
    self.assertTrue(all(x['status']=='DECISION_REQUIRED' for x in d['decisions']))
    self.assertEqual(d['testCaseStatus'],['NOT_RUN'])
    self.assertEqual(d['gates'][0]['status'],'NOT_APPROVED')
    self.assertEqual(d['gates'][1]['status'],'NOT_STARTED')
if __name__=='__main__':unittest.main()
