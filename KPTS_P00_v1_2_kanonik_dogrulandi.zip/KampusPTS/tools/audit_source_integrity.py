#!/usr/bin/env python3
"""Verify 56 immutable reference files and 49 exact P00 working files.
Reads frozen original source hashes from file-sha256.json, not an AI-generated manifest.
"""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
NON_P00={'P01-README.md','P76-README.md','docs/gates/G1-P04-submission-checklist.md','docs/gates/G3-P08-readiness.md','docs/p05/01-architecture-blueprint.md','docs/p76/FINAL-HANDOFF.md','docs/p76/OPEN-ACCEPTANCE-ITEMS.md'}

def audit():
  refs=json.loads((ROOT/'file-sha256.json').read_text(encoding='utf8'))['files']
  if len(refs)!=56:return ['Expected 56 source entries'],0,0
  bad=[];a=b=0
  for obj in refs:
    path,expected=obj['path'],obj['sha256']
    for root,kind in [(ROOT/'P00_REFERENCE','reference')]+([] if path in NON_P00 else [(ROOT/'KampusPTS','working')]):
      p=root/path
      if not p.is_file():bad.append(f'MISSING {kind} {path}');continue
      actual=hashlib.sha256(p.read_bytes()).hexdigest()
      if actual!=expected:bad.append(f'HASH_MISMATCH {kind} {path}')
      else:
        if kind=='reference':a+=1
        else:b+=1
  return bad,a,b

if __name__=='__main__':
  bad,a,b=audit();print(f'REFERENCE={a}/56 WORKSPACE={b}/49')
  for x in bad:print(x,file=sys.stderr)
  print('SOURCE_HASH_PASS' if not bad else 'SOURCE_HASH_FAIL')
  sys.exit(bool(bad))
