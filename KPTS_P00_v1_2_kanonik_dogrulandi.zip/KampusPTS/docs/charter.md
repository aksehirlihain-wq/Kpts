# P00 — Proje Charter ve G0 Yetkilendirme Taslağı

**Ürün:** Kampüs PTS Gelir Yönetim Platformu  
**Sürüm/tarih:** P00 v1.0 / 20.10.2026  
**Karar:** `REVIEW_REQUIRED`; kurum sponsoru ve kurullar **atanmadı / imzalamadı**.

## 1. Amaç
Üniversitelerin araç geçişleri ve ücretlendirilebilir kampüs hizmetleri için üretici bağımsız olay alma, oturum, tarife, tahsilat, e-Fatura/e-Arşiv, alt defter, ERP ve raporlamayı tek denetlenebilir çatıya taşımak. Çoklu kampüs, çoklu yasal işletme ve çoklu ödeme/e-belge sağlayıcı modeli desteklenir. **Ücret almaya hukuken yetkili hizmet kategorileri ayrıca doğrulanır; kampüs/yaya girişlerinin ücretli olması varsayılmaz (`DEC-027`).**

## 2. Mevcut sistem koruması
GV-ASManager 6.3.0 personel/idari geçiş yetkisinde kaynak otoritedir; GV-LPR2812-DL mevcut PTS bileşenidir. Yazılım bunlara kanıtsız komut göndermeyecek; kullanıcı/erişim verisini izinsiz değiştirmeyecek.

## 3. Kapsam içi
Modüler monolit hizmetleri: Integrations, Sessions, Entitlements, Subscriptions, Tariffs, Quotes, Payments, Wallet (karara bağlı), Invoicing, Ledger, Reconciliation, GateDecision, Exceptions, IdentityAccess, Audit, Notifications, Reporting, Portal, Kiosk. P00 çıktısı **tasarım ilkeleri ve kayıt sistemi** olup modül implementasyonu değildir.

## 4. Kapsam dışı / otomatik yetki yok
- Üreticinin belgelenmemiş API'sini kullanma, firmware değişimi, ASManager DB yazma.
- Canlı bariyer, gerçek ödeme, gerçek e-belge gönderimi ve banka fon dağıtımı.
- İSG sisteminin yazılımdan kontrolü; tahliye, fotosel ve emniyet devrelerinde değişiklik.
- Kurum onayı olmadan vergisel ve mali karar atama, plaka üzerinden kişisel bilgi ifşası.
- Özel entegratör/PSP lisansı varmış gibi davranma, muhasebe kayıtlarının tek başına yasal niteliğine hükmetme.

## 5. Başarı ölçütleri (gelecekte kanıtlanacak)
1. Onaylı gerçek geçiş kanıtı ile hesap açma/kapama; yinelenen okuma mali olay çoğaltamaz.
2. Kanıtlanmış ödeme tekil tahsil edilir; settlement ayrıca mutabık kalır.
3. Doğru `LegalEntity`, merchant, issuer ve ERP eşleşmesi; tarih-sürümlü hukukî ilişki.
4. Dengeli POSTED defter, ters kayıt ve audit; çift kayıt yok.
5. Kapatılabilir gerçek cihaz/mali özellik bayrakları ve güvenli rollback.
6. İnsan onaylı kritik kararlar; BİDB/Mali İşler/Güvenlik/İSG UAT.

## 6. Paydaş ve sorumluluk taslağı
Sponsor/Rektörlük (nihai kabul), BİDB (teknik sahibi), Güvenlik (fiziksel geçiş sahibi), Mali İşler/Strateji/Döner Sermaye (gelir ve vergi), Hukuk/KVKK (hukuki sorumluluk), İSG (can güvenliği), Öğrenci İşleri/İK (referans kimlik), işletmeci, ERP sahibi, tedarikçiler, iç denetim. Ad-soyad, imza ve devir sözleşmeleri **UNKNOWN**.

## 7. Yönetişim
Kapılar `G0..G9`, ayrıntı `docs/governance/gates.md`. Her aşama için REQ→UC/TC→EVD→Gate izlenebilirliği, değişiklik kontrolü ve net GO/NO-GO gerekir. İlgili RACI `docs/governance/raci.md`'de taslaktır.

## 8. P00 somut teslimatları
`AGENTS.md`, charter, matriks, kod/depo standartları, karar/riski/blokajı/izlenebilirliği kaydeden CSV'ler, şablonlar, G0/G1 kontrolleri, kontrol scriptleri. İmza ve gerçek üretici kanıtı henüz yoktur.

## 9. G0 imza alanı
Sponsor: __________ Tarih: ______  Karar: GO / NO-GO / CONDITIONAL  
BİDB: __________ Tarih: ______  Mali İşler: __________ Tarih: ______  
Güvenlik: __________ Tarih: ______  İSG/Hukuk görüşleri: __________  
Karar referansı: `DEC-___` / Tutanak: __________  
**İmza olmadan G0 durumu: `NOT_APPROVED`.**
