# Kaynak Gerçeklik Kayıtları (CSV)

- `requirements.csv`: önceki v1.0 belgesindeki `REQ-001..040` ayrılmadan korunur.
- `nfr.csv`: önceki `NFR-001..016` korunur.
- `decisions.csv`: v2.1 `DEC-001..025` ve çoklu tahsilat kararları `DEC-026..031` korunur.
- `risks.csv`: v2.1 `RISK-001..015` taslak risk skorları `ASSUMED`.
- `blockers.csv`: açık teknik, mali, fiziksel ve onay engelleri.
- `traceability.csv`: 56 REQ/NFR kaydının mevcut UC, TC, EVD bağlantıları. Boş bağlantı `NOT_YET_DEFINED`; test geçildi iddia edilmez.
- `test-cases.csv`: 10 **tasarlanmış**, tamamı `NOT_RUN` senaryo.
- `gates.csv`: G0 `NOT_APPROVED`, kalanları `NOT_STARTED`.

UTF-8 BOM CSV (Excel ile açılabilir), `;` yalnız referans çoklu değeri için. ID asla yeniden kullanılmaz veya sessiz silinmez; değişiklikler sürümlü CR ile işlenir. `owner_role` doldurulmuş olması gerçek kişi ataması olduğu anlamına gelmez. `due_date=TBD` onay sırasında değiştirilir.
