# P00 — Bağımsız Kanonik Restorasyon ve Teknik Denetim

**Tarih:** 2026-10-30  
**Kapsam:** P00 belge, kayıt, salt-okunur önizleme, kaynak bütünlüğü.  
**Kaynak:** Kullanıcı orijinal teknik paketinden seçilmiş ve daha önce SHA-256 değeri alınmış 56 kaynak dosya.

## Geri yükleme

- `P00_REFERENCE/` içinde **56 değişmez kaynak dosyası** ve kökte `file-sha256.json` vardır.
- `KampusPTS/` içinde **49 P00 çalışma dosyası** kaynak baytlarıyla birebir eşitlenmiştir.
- Diğer 7 dosya ilerideki aşamalara ait bağlamsal referanstır; çalışma dosyasına kopyalanmamıştır.
- React önizlemesi `PREVIEW_ONLY`; gerçek .NET backend, ödeme, cihaz veya banka bağlantısı değildir.
- Eski AI Studio düzeltme raporu `docs/reviews/SUPERSEDED_P00-v1.1_AI_Studio.md` altında **geçersiz tarihsel kanıt** olarak saklanmıştır.
- `KampusPTS/tools/generate_p00_preview.py` gerçek P00 CSV/Markdown dosyalarından `src/data/p00-canonical.json` üretir.

## Teknik ve kurumsal kapılar

- P00 kaynak bütünlüğü sadece dosya ve kayıt uygunluğudur; G0 `NOT_APPROVED`, test senaryoları `NOT_RUN`.
- DEC-001 dahil **31 karar** `DECISION_REQUIRED`, **8 BLK** `OPEN`.
- Gerçek .NET/PostgreSQL/PSP/e-belge/ERP/cihaz çalıştırma: `NOT_RUN / NOT_AVAILABLE`.
- Dışa aktarım ve arayüz derlemesi ayrıca doğrulanmalıdır; bir denetim raporu yazılması üretim kabulü değildir.

## Tekrar edilebilir yerel komutlar

```bash
cd KampusPTS
python3 tools/audit_source_integrity.py
python3 tools/validate_p00.py
python3 -m unittest discover -s tests -v
python3 tools/generate_p00_preview.py
python3 tools/build_manifest.py
sha256sum -c manifest.sha256
```

Bağımsız kanıtlar ZIP'i inceleyen kişi tarafından kendi ortamında tekrarlanmalıdır.

## 30.10.2026 Bağımsız çalıştırma sonucu (bu paket hazırlanırken)

| Komut | Gerçek sonuç |
|---|---|
| `python3 tools/audit_source_integrity.py` | **PASS — REFERENCE 56/56; WORKSPACE 49/49** |
| `python3 tools/validate_p00.py` | **PASS — P00 structural checks only** |
| `python3 -m unittest discover -s tests -v` | **6/6 PASS** (3 özgün, 3 bağımsız regresyon) |
| `python3 tools/generate_p00_preview.py` | **PASS — 12 K, 10 G kayıtlı statik özet** |
| `python3 tools/build_manifest.py` | **PASS — 60 içerik dosyası** |
| `sha256sum -c manifest.sha256` | **PASS** |
| `npm install --offline` | **NOT_AVAILABLE — @google/genai bağımlılığı önbellekte yok, ENOTCACHED** |
| `npm run lint` / `npm run build` | **NOT_RUN — bağımlılıklar kurulamadı** |
| `.NET build`, PostgreSQL, dış sağlayıcı, saha entegrasyonu | **NOT_RUN / NOT_AVAILABLE** |

Bu sonuçlar yalnız bu paket üzerindeki yerel ortam denetimleridir. AI Studio'ya aktarımdan sonra aynı komutlar yeniden çalıştırılmalıdır. **P00 yerel kaynak durumu: SOURCE_INTEGRITY_VERIFIED. Kurumsal durum: G0 NOT_APPROVED.**
