# REQ-### — Kayıt Şablonu

**Kimlik:** REQ-___  
**Statü:** NOT_STARTED  
**Son değişiklik UTC:** UNKNOWN  
**Bağlantılar:** __________

## 1. İş ihtiyacı
UNKNOWN

## 2. Kapsam ve istisnalar
UNKNOWN

## 3. Given/When/Then kabul ölçütü
UNKNOWN

## 4. Bağlı UC
UNKNOWN

## 5. Bağlı TC
UNKNOWN

## 6. Kanıt EVD (NOT_RUN)
UNKNOWN

## 7. Sahip
UNKNOWN

## 8. Kapı
UNKNOWN

## 9. Durum
UNKNOWN

**UYARI:** Gerçek onay/test/kanıt yoksa PASS yazmayın.
