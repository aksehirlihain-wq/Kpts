# RISK-### — Kayıt Şablonu

**Kimlik:** RISK-___  
**Statü:** NOT_STARTED  
**Son değişiklik UTC:** UNKNOWN  
**Bağlantılar:** __________

## 1. Sebep
UNKNOWN

## 2. Olasılık 1-5 (ASSUMED)
UNKNOWN

## 3. Etki 1-5 (ASSUMED)
UNKNOWN

## 4. Azaltım
UNKNOWN

## 5. Risk sahibi
UNKNOWN

## 6. Kalan risk
UNKNOWN

## 7. Kapı/BLK
UNKNOWN

## 8. Yeniden değerlendirme tarihi
UNKNOWN

**UYARI:** Gerçek onay/test/kanıt yoksa PASS yazmayın.
