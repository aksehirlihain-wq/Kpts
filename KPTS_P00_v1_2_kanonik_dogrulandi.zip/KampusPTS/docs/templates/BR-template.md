# BR-### — İş Kuralı Şablonu

**Kimlik:** BR-___  
**Durum:** NOT_STARTED

## Kararın dayanağı ve sürümü
UNKNOWN

## Hizmet / kampüs / tüzel kişi kapsamı
UNKNOWN

## Girdi koşulları, öncelik ve negatif durumlar
UNKNOWN

## Yürürlük tarihleri ve geriye uygulama
UNKNOWN

## Test/UC/REQ/EVD bağlantıları
NOT_RUN

## Hukuki/Mali onay
NOT_APPROVED
