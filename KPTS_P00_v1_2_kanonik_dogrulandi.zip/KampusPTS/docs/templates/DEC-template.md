# DEC-### — Kayıt Şablonu

**Kimlik:** DEC-___  
**Statü:** NOT_STARTED  
**Son değişiklik UTC:** UNKNOWN  
**Bağlantılar:** __________

## 1. Konu / neden
UNKNOWN

## 2. Alternatif A/B/C/D
UNKNOWN

## 3. Hukuki/saha/finans etkisi
UNKNOWN

## 4. Önerilen karar
UNKNOWN

## 5. Karar sahibi rol ve gerçek kişi
UNKNOWN

## 6. Son tarih (TBD)
UNKNOWN

## 7. Gerekli kanıt EVD
UNKNOWN

## 8. Etkilenen G kapısı
UNKNOWN

## 9. Statü DECISION_REQUIRED
UNKNOWN

## 10. İmza
UNKNOWN

**UYARI:** Gerçek onay/test/kanıt yoksa PASS yazmayın.
