# Başlangıç RACI Taslağı
R = işi yürüten, A = nihai karar/veri sorumlusu, C = danışılan, I = bilgilendirilen. **Aşağıdaki tabloda rol isimleri atanmamış kişi değildir; kurum imzaları beklenir.**

| Karar | Sponsor | BİDB | Güvenlik | Mali İşler | Hukuk/KVKK | İSG | Dış sağlayıcı |
|---|---|---|---|---|---|---|---|
| P00/G0 | A | R | C | C | C | C | I |
| Saha POC | I | R | A | I | C | C | C |
| Ücret hakkı/tarife | C | I | C | A/R | C | I | I |
| Merchant ve ödeme | I | R | I | A | C | I | C |
| Fatura/vergisel karar | I | C | I | A/R | C | I | C |
| Bariyer icra otoritesi | I | R | A | I | C | C | C |
| Tahliye/emniyet | I | C | R | I | C | A | C |
| IAM/güvenlik | I | A/R | C | C | C | I | I |
| KVKK veri sorumlusu/aktarımlar | I | R | C | C | A | I | C |
| Muhasebe ERP kabulü | I | R | I | A | C | I | C |

**Kayıt kuralı:** Aynı kritik finans hareketinde hazırlayan ve onaylayan farklı kişiler; banka hesabı ve tüzel kişilik eşlemesi çift kontrol. Çoklu tüzel kişi veri sorumlusu/işleyen rolü sözleşmeye bağlıdır (`DEC-029`).
