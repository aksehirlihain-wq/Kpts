# Değişiklik ve Konfigürasyon Yönetimi

1. Değişiklik `CR-###` oluşturularak talep edilir. İşlem/finans/İSG/KVKK etkisi ve etkilenen REQ/DEC/ADR/EVD/Gate yazılır.
2. Karar sahibi aynı rol tarafından kapsam/etki analizi yapılır; güvenlik/mali/İSG kritik değişimde dört göz + ilgili kurul onayı şarttır.
3. Mimari değişiklik için ADR'de alternatifler, kabul/red gerekçeleri, geri alma ve gerçek kanıt yer alır.
4. `DECISION_REQUIRED` maddeleri tamamlanmadan üretim parametresi açılmaz. Tarihi işlem ve belgeler sessiz migrate edilmez.
5. Her release değişkeni (config, schema, adapter, tariff, finance rule) sürümlü, imzalı ve geriye alınabilir olmalıdır.
6. Repo CI kontrolü geçse bile kurum onayı bulunmazsa yalnız `DESIGNED`.
