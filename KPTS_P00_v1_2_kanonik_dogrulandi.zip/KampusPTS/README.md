**P73 (23.10.2026)** — Üretim/test TypeScript tip-kapsamı ayrıldı; P72 LAB build aşamaları hataya göre izole edildi; gerçek TS2688 eksik bağımlılık engeli doğrulandı. Ayrıntılar: [P73-README.md](P73-README.md). Gerçek .NET/React/PostgreSQL kabulü NOT_RUN/BLOCKED; G5/G6/G7 NO-GO.

**P43 (22.10.2026)** — Reporting kalıcı DEV-LAB alarm kaynağı, atomik outbox, yeniden başlama sonrası idempotent korelasyon, P42 salt-okunur kaynak köprüsü, P34 panel. Üretim kabulü değildir. Bkz. `P43-README.md`.

**P41 (22.10.2026)** — Olay korelasyonu ve müdahale dosyaları için süreç içi LAB kaynak akışı, Reporting korelasyon önerileri, Exceptions durum makinesi, global ops API, eskalasyon inceleme, React paneli ve DB REVIEW_ONLY taslakları. G5/G6/G7 NO-GO; .NET/PostgreSQL/React runtime doğrulanmadı. Bakınız `P41-README.md`.

**P40:** Operasyonel izleme, LAB alarm merkezi, Reporting/Notifications SQL taslakları; kaynak denetimi; canlı merkezi log bağlı değil. Bakınız `P40-README.md`.

> **P39 (22.10.2026)** — Ayrı CI doğrulama ve korumalı imaj yayımlama, JSON operational telemetry ve operatör sağlık görünümü: [P39-README.md](P39-README.md). İmaj build/sign/deploy NOT_RUN; React lockfile MISSING; G5/G6/G7 NO-GO.

> **P36 (22.10.2026)** — Domain owner publisher, atomic projection ve veri kökeni sözleşmeleri: [P36-README.md](P36-README.md). Canlı kaynak feed bağlanmadı; G5/G6/G7 NO-GO.

> **P34 (22.10.2026)** — Bütünleşik operatör çalışma alanı ve kaynak normalizasyonu: [P34-README.md](P34-README.md). P23 LAB artık yalnız `VITE_OPERATOR_MODE=P23_LAB` ile açılır. Bu bir çalışma/kurum kabulü değildir; G5/G6/G7 NO-GO.

> P24 operator READ-only backend API source: `P24-README.md`; G5/G6/G7 NO-GO.

# P23 — Operatör Yönetim Paneli (LAB ön izlemesi)

Bkz. [P23-README.md](P23-README.md). Önceki P00–P22 kaynak ve onay durumları korunur. G5/G6/G7 NO-GO.

# P22 — ERP Integration / G6 review

See `P22-README.md`. All live outputs disabled; G5/G6 NO-GO.

# Kampüs PTS Gelir Yönetim Platformu — Kurumsal Tasarım ve Kanıt Deposu v1.6

Bu depo **çalışan ürün değil**, aşama bazlı doküman/sözleşme/test planı ve doğrulama deposudur. P00–P05 tasarımı korunarak P06 güvenlik ve KVKK mimarisi eklenmiştir.

- `AGENTS.md`: A1–A10 proje anayasası ve değişmez ilkeler
- `P01-README.md`…`P06-README.md`: faz okuma yönergeleri
- `docs/p06/`: STRIDE tehdit modeli, kimlik, erişim, kişisel veri, şifreleme, uygulama güvenliği, G2
- `docs/registries/`: P00–P04 karar/gereksinim ana kayıtları, **onaysız olarak korunur**
- `docs/p05/`: 19 modül, ADR-004…019 ve saha/finansal mimari
- `tools/validate_p06.py`: statik içerik referans/şema/izlenebilirlik kontrolü

**Onay:** G0 NOT_APPROVED; G1 NOT_STARTED; G2 NOT_APPROVED. P06'nın eklediği ADR/DEC'ler yalnız **PROPOSED**, geçerli hukuk/mali kararı değildir. `evidence/P06/README.md` dosyası saha/kurum kanıtlarının teslim edilmediğini belirtir.


## P09 (v1.9) — App services and reliable event pointers
- `P09-README.md`: mimari ve durum
- `src/KampusPTS.Messaging/`: neutral messaging contracts and dispatcher
- `src/Modules/KampusPTS.Modules.Sessions/Application/SessionsMessageStore.cs`: PostgreSQL proof-of-concept adapter
- `tests/KampusPTS.MessagingSmoke/`: C# sandbox smoke test (NOT_RUN locally)
- `docs/p09/`: 48 design-only BDD cases, ADR, decisions and G3
- `evidence/P09/`: Python static/regression passes, .NET/DB NOT_RUN
**LIVE NO-GO, G0–G3 NOT APPROVED.**


## P10 addition (2026-10-21)
See [P10-README.md](P10-README.md) for scoped OIDC/JWT authorization and audit draft. G3 NO-GO; runtime and IdP not verified.


## P11 (v1.11) — Sadece sentetik kaynak olay alımı
Bkz. [P11-README.md](P11-README.md). GeoVision ve ONVIF adaptörleri gerçek kanıt yokken kapalıdır.


## P12 addendum (2026-10-21)
Laboratory-only passage correlation and simulated session lifecycle. See `P12-README.md`. G4 is NO-GO.


## P13
Mali hak, abonelik sözleşmesi ve fiziksel erişim iş emri birbirinden ayrıdır. P13 kaynakları için `P13-README.md` dosyasına bakınız. Canlı tahsilat/ASManager/ERP/e-belge işlemleri KAPALI.


## P14
Ayrıntılar: [P14-README.md](P14-README.md). Yalnız sentetik mali/harici erişim mutabakatı. G4 NO-GO.

## P15 / G4
See `P15-README.md` for **lab-only** in-process P11–P14 smoke, 48 unexecuted BDD scenarios, operational runbooks, and strict G4 NO-GO.


## P16 — Tarife Motoru
P16 kaynak, kayıt ve statik testleri: [P16-README.md](P16-README.md). Eski sürüm içeriği korunur; G5 NO-GO.


P17 SOURCE_DRAFT: See P17-README.md; financial posting and live integrations remain disabled.

P18 SOURCE_DRAFT: See P18-README.md; live payment providers and all financial effects OFF.

## P19 extension — v1.19 (21 October 2026)
- Read `P19-README.md` / `docs/p19` for LAB-only payment-evidence, cash-shift, reconciliation and exception code.
- 64 planned BDD cases, 8 open decisions, 14 missing evidence items; G5 remains NO-GO.
- No real PSP/bank/cash/ledger/ERP commands; SDK and PostgreSQL tests not run.


## P20 — LAB Sub-Ledger
See `P20-README.md`: synthetic balanced journal and reversal source; G6 NO-GO.

## P21 — e-belge LAB (2026-10-22)
See `P21-README.md`. No real invoice issuance, approved G6 or GİB transmission.

## P25 controlled extension
See `P25-README.md` and `docs/p25` for owner-scoped synthetic read federation and explicit G7 blockers. Previous G5/G6/G7 NO-GO statuses remain.

## P26 (v1.26) — Controlled domain-owned PostgreSQL read adapters
Six owner read ports + P26OwnerReadPort contracts + P26 SELECT-only schema proposal. Existing data cannot be promoted to CONFIRMED. No live publisher, .NET, PostgreSQL or React runtime claims. See P26-README.md. G5/G6/G7 remain NO-GO.

## P27 — Operatör inceleme dosyası iş akışı

Yeni domain-owned durum değiştiren çalışma kodu ve React ekranı `P27-README.md`
ve `docs/p27/` altında belgelenmiştir. Test/açılış onayı ertelenmiştir; G5–G7 açık.


## P28 — Task, notification event inbox and SLA source
See [P28-README.md](P28-README.md) for Exceptions-owned task commands,
Notifications-owned inbox, scoped API, React workspace, REVIEW_ONLY migrations,
and runtime deferrals. G5/G6/G7 remain NO-GO; no live notification or financial command.

## P29 (v1.29) — Workforce & In-App Notifications
See [P29-README.md](P29-README.md). New schedules, dispatch, in-app notices and business-hours SLA are lab-source only; G5–G7 NO-GO.


## P30 extension (22.10.2026)
See [P30-README.md](P30-README.md) for institution-verified staff directory, competence-gated dispatch, and verified in-app routing. No HR master edits or production operation.


## P31 — Organisational changes and delegation
See [P31-README.md](P31-README.md). P31 uses signed HR event intake, scoped revocation fences, positive-change review and two-reviewer non-granting delegation. All new flags OFF; source not connected, SQL not applied, G5/G6/G7 remain NO-GO.


## P32 (v1.32) — Trusted HR revocation -> Exceptions guarded reroute
See [P32-README.md](P32-README.md). Signed P31 fences are staged to IdentityAccess Outbox,
consumed idempotently in Exceptions Inbox, and affected assigned tasks safely unassigned.
Automatic task reassignment is separately DISABLED until institutional approvals; when enabled,
P29/P30/P31 are rechecked. No IAM grants or GeoVision command. G5/G6/G7 NO-GO.


## P33 — Kurumsal Olay Kuyruğu (v1.33)

`docs/p33` ve `deploy/p33` inceleme belgeleri; IdentityAccess alanında SKIP LOCKED kiralamalı kuyruk, sınırlı yeniden deneme, karantina ve çift MFA onaylı replay. `P33Worker:Enable` varsayılan kapalıdır; P32 işçisi ile eşzamanlı çalışamaz. P32 Exceptions Inbox değişmez. React ön izlemesi `VITE_OPERATOR_MODE=P33_QUEUE`; kurumsal kaynak/SOO yoksa fail-closed. SQL/derleme canlı çalışma doğrulanmadı.


## P35 — Kurumsal API Composition Root
Başlangıç kaynağı: `P35-README.md`; P07–P33 modül kayıtları tek host altında açık bileşenlere ayrıldı.

## P37 — Operatör Paneli–Backend Servis Bağlantıları
Birleşik P37 iş akışı P34 ana görünümündedir. P24–P29 var olan servis uç noktalarını ortak token callback ile kullanır; P27 inceleme → P28 görev → P29 vardiya zinciri tamamen sunucu onaylı ilerler. Gerçek kurumsal OIDC/data kaynağı yoktur. Ayrıntılar: `docs/p37/`. G5/G6/G7 NO-GO.

## P38 — Deployment/Operations (2026-10-22)
See `P38-README.md` and `deploy/p38/`. Source-only, no real Docker/.NET/PG build; live effects OFF.
