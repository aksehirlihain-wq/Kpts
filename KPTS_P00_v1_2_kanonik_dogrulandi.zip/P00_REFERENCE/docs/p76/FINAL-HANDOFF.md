# KAMPÜS PTS v1.76 — Nihai teknik kaynak kapanışı

## Kapanış kapsamı

P00–P75'in kaynak dosyaları korunur. P76, v1.75 üzerine **yalnız denetim, kanıt ve teslim belgeleri/CI kontrolü ekler**. Bu durum uygulamanın derlenebilirliğini, tüm iş akışlarının tamamlandığını veya üretim kabulünü kanıtlamaz. Son paket ismi, gerçek kullanılabilir sistem sertifikası değildir.

### Bütünlük zinciri

1. `docs/p76/P75_baseline_manifest.sha256` dosyası v1.75 özgün manifest kopyasıdır. Bilinen SHA-256 değeri `4cf2175d69a720dc611664111f174e5f0bbb85c2217d2e7349506d8ef9704754` ile doğrulanır.
2. `manifest.sha256` son sürümdeki tüm dosyaları (manifest kendisi hariç) tekil, sıralı SHA-256 kayıtlarla listeler.
3. `tools/p76/final_gate.py --zip ...` gerçek ZIP dosyasındaki tüm girdileri doğrular; tarihsel kaynakların kaybolmasını veya değişmesini, yinelenen girdileri, yoldan çıkmayı, symlink'i, JSON yinelenen anahtarlarını ve sahte kabul kayıtlarını reddeder.
4. `evidence/P76/final-acceptance-register.json` yalnız kaynak teslimi statüsünü belirtir. `NO-GO` doğrulamasını kaldırma yetkisi yoktur.
5. Paketin bütünü için harici teslim `KampusPTS_P76_Kaynak_Butunlugu_ve_Teslim_Kaniti.json` içinde arşiv SHA-256 değeri sağlanır. Başka kanaldan kimlik doğrulaması yapılmamış digest, elektronik imza değildir.

## Açık zorunlu koşullar

| Ana başlık | P76 durumu | Önkoşul / işlem |
|---|---|---|
| .NET 10 Release derlemesi | NOT_RUN | .NET 10 SDK/NuGet erişimi bulunan izole LAB, gerçek `dotnet build` logu |
| 20 C# Smoke testi | NOT_RUN | Release çıktıları ve sürüm bağlı test kanıtları |
| Gerçek API/JWT erişim testleri | NOT_RUN | Yalnız yetkili laboratuvar, IAM/MFA/Audit negatif ve pozitif testleri |
| PostgreSQL 16 / FORCE RLS | NOT_RUN | Geçici ayrı veritabanı, P74 ilişki kısıtı DBA incelemesi, iki kapsam testi |
| Finansal ve kapı iş senaryoları | NOT_RUN | Sentetik, güvenlik kilitleri açık, test sağlayıcıları doğrulanmış saha değil |
| npm kilit dosyası | BLOCKED | Doğrulanmış dış kaynakta üretim ve insan incelemesi; depoda henüz yok |
| React üretim derlemesi | BLOCKED | İncelenmiş lockfile + `npm ci` + üretim build |
| G5/G6/G7 ve resmî kabul | NO-GO | Bağımsız kanıtlar + yetkili kurumsal karar |

## İşletme ve teslime yönelik sınırlar

- **Üretim komutları kapalıdır.** Bu kaynak teslimi üzerinden canlı ödeme, bariyer, GeoVision, e-belge veya ERP entegrasyonunu başlatmak uygun değildir.
- Eksik veya `UNKNOWN` veriler başarıya dönüştürülmez. Test hiç çalışmadıysa `NOT_RUN`; bağımlılık yoksa `BLOCKED` olarak kalır.
- P74 SQL kısıtı uygulanmadı; DBA kararı zorunludur.
- `P76_FINAL` yalnız kaynak sürümünün kapanışıdır. Kabul için yeni aşama numarası üretmek zorunlu değildir: mevcut açık iş kalemlerinin laboratuvar ve kurum sahiplerince kapatılması gerekir.

## Kullanıcı teslim kontrolü

Kaynak ZIP, düzenlenebilir Word raporu ve bağımsız SHA-256 kanıt JSON'u birlikte saklanmalıdır. ZIP içinde `docs/p76/`, `tools/p76/`, `evidence/P76/` ve geçmiş P00–P75 dosyaları vardır. Arşiv başlığının `KampusPTS_v1_46r1` olması tarihsel teknik kök adıdır; sürüm manifesti v1.76 olarak paketlenmiştir.
