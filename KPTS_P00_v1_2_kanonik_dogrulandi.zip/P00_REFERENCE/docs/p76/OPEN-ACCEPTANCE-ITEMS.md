# Nihai kapanış sonrası kalan kabul ve işletim görevleri

Bu liste yeni bir P77 geliştirmesi önermez. P76 kaynak kapanışından sonra bağımsız laboratuvar ve kurumsal kabul çalışmalarına ilişkin eksik kanıtlardır.

| Kimlik | Gereken karar veya kanıt | Durum | Sorumluluk rolü |
|---|---|---|---|
| A01 | İncelenmiş `package-lock.json` (P61/P71 politika kontrolü) | BLOCKED | Frontend / bağımlılık sahibi |
| A02 | Gerçek `dotnet restore/build` ve hataların kapatılması | NOT_RUN | Backend / CI laboratuvarı |
| A03 | 20 C# Smoke ve Release SHA-256 uzlaştırması | NOT_RUN | Backend / QA |
| A04 | İzole API; anonim, düşük ve doğru yetkili JWT, Audit, MFA | NOT_RUN | IAM / güvenlik / QA |
| A05 | PostgreSQL 16, RLS, çift kapsam, P74 constraint DBA inceleme | NOT_RUN | DBA / güvenlik |
| A06 | 15 P75 iş senaryosunun LAB koşullarında yürütülmesi | NOT_RUN | İş alanı sorumluları / QA |
| A07 | `npm ci`, test ve React production build | BLOCKED | Frontend / CI |
| A08 | G5/G6/G7 kanıtlı değerlendirme ve yetkili kabul kararı | NO-GO | Kurumsal kabul makamı |

**Kimlik/rol bilgisi:** Gerçek kişiler, kurum kararı, imza, onay tarihi veya gerçekleştirilmiş test için bu belge iddiada bulunmaz. Dış sistem bağlantılarında UNKNOWN ≠ FALSE; sanal laboratuvar verisi gerçek mali/erişim yetkisi doğurmaz.
