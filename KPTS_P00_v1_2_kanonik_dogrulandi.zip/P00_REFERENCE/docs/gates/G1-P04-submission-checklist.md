# P04.14 — G0/G1/G5/G6/G9 kapı ve blokaj matrisi

## Kanonik durumu koru
`decisions.csv` DEC-001..031 ve `blockers.csv` BLK-001..008 hiçbir şekilde overwrite edilmedi. P02 öneriler DEC-032..037 ve P03 öneriler ayrı namespace içinde kalır. P04 soruları da yeni kanonik karara dönüştürülmedi. Sponsor onayı olmadan G0 veya G1 durumunu değiştirme.

## G1 (P01..P04) imza önkoşulları
- [ ] G0 sponsor onayı EVD.
- [ ] P01 kampüs/finans/paydaş envanteri ve gerçek kurum görevlileri.
- [ ] P02 üretici payload ve fiziksel geçiş kanıtı saha POC.
- [ ] P03 SRS/use case review ve izlenebilirlik onayı.
- [ ] DEC-001 ve DEC-027 hukuki yetki kararı.
- [ ] DEC-002/014/028/030 vergi/issuer/belge tipi karar belgesi.
- [ ] DEC-003/026/031 PSP merchant/beneficiary yazılı sözleşmesi.
- [ ] DEC-005/022 ERP ve mutabakat protokolü.
- [ ] KVKK, saklama, iade/SoD ve aşamaların görev/sorumlu atamaları.
- [ ] Açık BLK listesi, tarih/owner ve G1 kurul GO/NO-GO tutanağı.

## Blokajlar
`BLK-001` gelir sahibi; `BLK-002` ücret yetkisi; `BLK-005` vergi/issuer; `BLK-006` PSP split/merchant; `BLK-008` G0. `BLK-003/004/007` saha tarafı hâlâ açık.

## Sonraki aşama
**P05 — Sistem Mimarisi ve ADR** yalnız onaylı konuları kesin olarak uygulayabilir. Ön tasarım ve test fixture çalışma izni kurumsal karardan ayrı; `LIVE_NO_GO` zorunlu.
