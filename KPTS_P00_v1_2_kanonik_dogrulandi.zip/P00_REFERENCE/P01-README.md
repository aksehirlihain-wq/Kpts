# P01 — Kurumsal ve Saha Keşfi / Birleşik P00+P01 Deposu

**Paket:** `KPTS-P01-DISCOVERY-1.0` • **Tarih:** 20.10.2026 • **Statü:** `DESIGNED / DATA_NOT_COLLECTED`  
**G0:** `NOT_APPROVED` (P00 imza kanıtı yok). **G1:** `NOT_STARTED` ve P01–P04 tamamlanmadan onaylanamaz.

P00 dosyaları değişmeden korunmuştur. P01 teslimatı sahada kullanılacak formlar, görüşme soruları, kurumsal ve teknik keşif protokolü, mali akış örnekleri, izlenebilirlik/kanıt planıdır. **Gerçek üniversite, cihaz, lisans, ERP ve ödeme bilgisi toplanmamıştır.**

## Başlangıç sırası
1. `docs/gates/G0-checklist.md` sponsor imzaları ile kontrol edilir; eksikler `BLK-008` üzerinden yönetilir.
2. `docs/p01/01-discovery-charter.md` kapsamı ve yetkili sorumluları netleştirir.
3. `docs/p01/02-stakeholder-interviews.md` sorularını paydaşlarla görüşür; toplantı tutanağını `evidence/P01/` altına imza + veri maskelemesi ile kaydeder.
4. `docs/p01/03-campus-field-survey.md` ile fiziki alanları inceleyip `docs/p01/data/*.csv` formlarını doldurur.
5. `docs/p01/04-integration-discovery.md`, `05-financial-discovery.md`, `06-privacy-security-discovery.md` ile P02/P04'e girdi üretir.
6. `docs/p01/08-scenarios.md` kapsam sınırlarını ve P03 iş senaryosu tohumlarını doğrular.
7. `python3 tools/validate_p01.py` yalnız **dosya yapısı, kayıt kimliği, örnek veri durumu ve politika** denetimi yapar; saha testine eşdeğer değildir.
8. `docs/p01/09-gate-readiness.md` ile P01 çıkış ve P02 devralma kararı alınır. `G1` ancak P01–P04 tamamlandığında ele alınır.

## Kritik davranış kuralları
- **UNKNOWN ≠ FALSE**; boş alan yerine `UNKNOWN`, tahmin yerine `ASSUMED` ve karar için `DECISION_REQUIRED`.
- PLATE_RECOGNIZED ≠ PASSAGE_CONFIRMED ≠ GATE_ACK.
- Personel fiziksel hakkının otoritesi ASManager; yeni platformdaki mali abonelik fiziksel erişim oluşturmaz.
- Gelir sahibi / tahsilat yetkilisi / merchant / fatura düzenleyici / ERP yetkilisi ayrı rollerdir.
- Ücretli kampüs/yaya giriş hakkı varsayılmaz. Otopark dışı hizmetler kurum hukuk kararı gerekir.
- Gerçek gate / ödeme / e-belge `OFF`; gerçek üretici payload'ı, endpoint'i veya test sonucu uydurulmaz.

## P01 teslimatlar
`01..10` numaralı dokümanlar; boş saha CSV'leri; görüşme, tutanak, kanıt şablonları; UC kataloğu; çıktı-kaynak haritası; doğrulama ve manifest. **Tüm P00 kayıt kimlikleri korunmuştur.**
